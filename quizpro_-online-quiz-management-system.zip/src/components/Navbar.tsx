import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { auth } from '../lib/firebase';
import { LogOut, LayoutDashboard, BookOpen, Award, User } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Navbar() {
  const { user, profile, isAdmin } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/login');
  };

  return (
    <nav className="sticky top-0 z-50 border-b border-white/10 bg-[#0a0a0a]/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2 text-2xl font-bold tracking-tighter text-blue-500">
          <Award className="h-8 w-8" />
          <span>QUIZPRO</span>
        </Link>

        <div className="flex items-center gap-6">
          {user ? (
            <>
              <Link to="/dashboard" className="flex items-center gap-2 text-sm font-medium text-white/70 transition-colors hover:text-blue-500">
                <BookOpen className="h-4 w-4" />
                Dashboard
              </Link>
              
              {isAdmin && (
                <Link to="/admin" className="flex items-center gap-2 text-sm font-medium text-white/70 transition-colors hover:text-blue-500">
                  <LayoutDashboard className="h-4 w-4" />
                  Admin
                </Link>
              )}

              <div className="flex items-center gap-4 border-l border-white/10 pl-6">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500/10 text-blue-500">
                    <User className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-medium text-white/90">{profile?.displayName}</span>
                </div>
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 text-sm font-medium text-white/50 transition-colors hover:text-red-400"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            </>
          ) : (
            <Link
              to="/login"
              className="rounded-full bg-blue-500 px-6 py-2 text-sm font-bold text-black transition-transform hover:scale-105 active:scale-95"
            >
              Get Started
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
