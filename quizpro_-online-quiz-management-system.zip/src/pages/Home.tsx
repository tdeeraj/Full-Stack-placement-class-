import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { BookOpen, Award, Users, ChevronRight, Sparkles } from 'lucide-react';

export default function Home() {
  return (
    <div className="relative min-h-[calc(100vh-80px)] overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 -left-20 h-96 w-96 rounded-full bg-blue-500/20 blur-[120px]" />
        <div className="absolute bottom-1/4 -right-20 h-96 w-96 rounded-full bg-cyan-500/10 blur-[120px]" />
      </div>

      <div className="mx-auto flex max-w-7xl flex-col px-6 pt-20 pb-32">
        <div className="grid gap-16 lg:grid-cols-2 lg:items-center">
          {/* Hero Content */}
          <div className="flex flex-col gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 self-start rounded-full border border-blue-500/20 bg-blue-500/5 px-4 py-1.5 text-xs font-bold tracking-widest text-blue-500 uppercase"
            >
              <Sparkles className="h-3 w-3" />
              THE FUTURE OF LEARNING
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display text-7xl font-black leading-[0.9] tracking-tighter uppercase sm:text-8xl xl:text-9xl"
            >
              Master <br />
              <span className="text-blue-500">Your Craft.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="max-w-md text-lg leading-relaxed text-white/60"
            >
              Professional-grade assessments designed to validate your skills. 
              Earn industry-recognized certifications and join a community of elite learners.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-wrap gap-4 pt-4"
            >
              <Link
                to="/dashboard"
                className="group relative flex items-center gap-2 overflow-hidden rounded-full bg-blue-600 px-10 py-5 text-lg font-black text-white transition-all hover:scale-105 active:scale-95"
              >
                <span className="relative z-10">START ASSESSMENT</span>
                <ChevronRight className="relative z-10 h-5 w-5 transition-transform group-hover:translate-x-1" />
                <div className="absolute inset-0 -translate-x-full bg-white transition-transform group-hover:translate-x-0" />
              </Link>
              <Link
                to="/login"
                className="rounded-full border border-white/10 bg-white/5 px-10 py-5 text-lg font-black text-white transition-all hover:bg-white/10"
              >
                SIGN IN
              </Link>
            </motion.div>
          </div>

          {/* 3D Visual Element */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotateY: -20 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="perspective-1000 hidden lg:block"
          >
            <div className="preserve-3d relative h-[600px] w-full">
              {/* Card 1 */}
              <motion.div
                animate={{ 
                  y: [0, -20, 0],
                  rotateZ: [-2, 2, -2]
                }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="glass absolute top-0 right-0 z-20 h-80 w-64 rounded-[2rem] p-8 shadow-2xl"
              >
                <Award className="mb-4 h-12 w-12 text-blue-500" />
                <div className="mb-2 text-xs font-bold text-white/30 uppercase tracking-widest">Certification</div>
                <div className="text-2xl font-black leading-tight">Advanced TypeScript</div>
                <div className="mt-12 h-1 w-full rounded-full bg-white/10">
                  <div className="h-full w-[85%] rounded-full bg-blue-500" />
                </div>
                <div className="mt-2 text-right text-xs font-bold text-blue-500">85% SCORE</div>
              </motion.div>

              {/* Card 2 */}
              <motion.div
                animate={{ 
                  y: [0, 20, 0],
                  rotateZ: [2, -2, 2]
                }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                className="glass absolute bottom-20 left-0 z-10 h-96 w-72 rounded-[2rem] p-8 shadow-2xl"
              >
                <BookOpen className="mb-4 h-12 w-12 text-blue-500" />
                <div className="mb-2 text-xs font-bold text-white/30 uppercase tracking-widest">Course Progress</div>
                <div className="text-2xl font-black leading-tight">Full-Stack Architecture</div>
                <div className="mt-32 flex flex-col gap-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="h-2 w-2 rounded-full bg-blue-500" />
                      <div className="h-2 flex-1 rounded-full bg-white/10" />
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Decorative Elements */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                <div className="h-[400px] w-[400px] rounded-full border border-white/5" />
                <div className="absolute top-1/2 left-1/2 h-[300px] w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/10" />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Stats Section */}
        <div className="mt-32 grid gap-8 border-t border-white/10 pt-16 sm:grid-cols-3">
          {[
            { label: "Active Students", value: "12K+", icon: Users },
            { label: "Quizzes Published", value: "450+", icon: BookOpen },
            { label: "Certificates Issued", value: "8.2K", icon: Award }
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex flex-col gap-2"
            >
              <stat.icon className="h-6 w-6 text-blue-500" />
              <div className="text-4xl font-black tracking-tighter">{stat.value}</div>
              <div className="text-xs font-bold text-white/40 uppercase tracking-widest">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
