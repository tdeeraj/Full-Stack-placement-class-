import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Award, Download, Printer, Loader2, ShieldCheck, Calendar, User, FileDown } from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

interface CertificateData {
  id: string;
  userId: string;
  quizId: string;
  attemptId: string;
  userName: string;
  quizTitle: string;
  issuedAt: string;
}

export default function Certificate() {
  const { id } = useParams(); // attemptId
  const [certificate, setCertificate] = useState<CertificateData | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCertificate = async () => {
      if (!id) return;
      const q = query(collection(db, 'certificates'), where('attemptId', '==', id), limit(1));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        const doc = snapshot.docs[0];
        setCertificate({ ...doc.data(), id: doc.id } as CertificateData);
      }
      setLoading(false);
    };
    fetchCertificate();
  }, [id]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = async () => {
    const element = document.getElementById('certificate-content');
    if (!element) return;

    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'px',
        format: [800, 600]
      });
      
      pdf.addImage(imgData, 'PNG', 0, 0, 800, 600);
      pdf.save(`Certificate-${certificate.quizTitle.replace(/\s+/g, '-')}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    }
  };

  if (loading) return (
    <div className="flex h-[60vh] items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
    </div>
  );

  if (!certificate) return (
    <div className="flex flex-col items-center justify-center gap-4 py-24 text-center">
      <Award className="h-16 w-16 text-white/20" />
      <h2 className="text-2xl font-bold">Certificate not found</h2>
      <button onClick={() => navigate('/quizzes')} className="text-blue-500 underline">Back to Quizzes</button>
    </div>
  );

  return (
    <div className="flex flex-col items-center gap-12 py-12">
      <div className="flex flex-col items-center gap-4 text-center">
        <h1 className="text-4xl font-black tracking-tighter uppercase">Your Achievement</h1>
        <p className="text-white/50">Congratulations on successfully completing the assessment.</p>
      </div>

      {/* Certificate Frame */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="print:m-0 print:p-0 print:shadow-none"
      >
        <div 
          id="certificate-content" 
          className="relative h-[600px] w-[800px] overflow-hidden p-2 shadow-2xl"
          style={{ 
            backgroundColor: '#ffffff',
            color: '#000000',
            border: '2px solid #d4af37',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)'
          }}
        >
          {/* Inner Border */}
          <div 
            className="h-full w-full border-[16px] p-12"
            style={{ borderColor: '#1d4ed8' }}
          >
            <div 
              className="relative flex h-full flex-col items-center justify-between border-2 p-8 text-center"
              style={{ borderColor: '#d4af37' }}
            >
              {/* Corner Ornaments */}
              <div className="absolute -top-1 -left-1 h-8 w-8 border-t-4 border-l-4" style={{ borderColor: '#d4af37' }} />
              <div className="absolute -top-1 -right-1 h-8 w-8 border-t-4 border-r-4" style={{ borderColor: '#d4af37' }} />
              <div className="absolute -bottom-1 -left-1 h-8 w-8 border-b-4 border-l-4" style={{ borderColor: '#d4af37' }} />
              <div className="absolute -bottom-1 -right-1 h-8 w-8 border-b-4 border-r-4" style={{ borderColor: '#d4af37' }} />

              {/* Decorative background watermark */}
              <div className="absolute inset-0 -z-10 flex items-center justify-center opacity-[0.03]">
                <Award className="h-[400px] w-[400px]" />
              </div>

              <div className="flex flex-col items-center gap-2">
                <div 
                  className="font-serif text-sm font-bold tracking-[0.5em] uppercase"
                  style={{ color: '#1d4ed8' }}
                >
                  Certificate of Achievement
                </div>
                <div className="h-px w-48" style={{ backgroundColor: '#d4af37' }} />
              </div>

              <div className="flex flex-col items-center gap-6">
                <div className="font-serif text-xl italic" style={{ color: '#4b5563' }}>
                  This is to certify that
                </div>
                <div 
                  className="font-serif text-5xl font-bold tracking-tight"
                  style={{ color: '#111827' }}
                >
                  {certificate.userName}
                </div>
                <div className="font-serif text-lg italic" style={{ color: '#4b5563' }}>
                  has successfully demonstrated proficiency and completed the assessment
                </div>
                <div 
                  className="text-2xl font-black tracking-wide uppercase"
                  style={{ color: '#1d4ed8' }}
                >
                  {certificate.quizTitle}
                </div>
              </div>

              <div className="grid w-full grid-cols-3 items-center gap-8 pt-8">
                <div className="flex flex-col items-center gap-2">
                  <div className="font-mono text-[10px] uppercase tracking-tighter" style={{ color: '#9ca3af' }}>
                    ID: {certificate.id.substring(0, 12).toUpperCase()}
                  </div>
                  <div className="h-px w-full" style={{ backgroundColor: '#e5e7eb' }} />
                  <div className="text-[10px] font-bold uppercase tracking-widest" style={{ color: '#4b5563' }}>
                    Verification Code
                  </div>
                </div>
                
                <div className="relative flex justify-center">
                  <div 
                    className="flex h-24 w-24 items-center justify-center rounded-full border-4 shadow-lg"
                    style={{ 
                      borderColor: '#d4af37',
                      backgroundColor: '#ffffff'
                    }}
                  >
                    <div 
                      className="flex h-20 w-20 flex-col items-center justify-center rounded-full border-2 border-dashed"
                      style={{ borderColor: '#d4af37' }}
                    >
                      <Award className="h-8 w-8" style={{ color: '#d4af37' }} />
                      <div className="text-[8px] font-black uppercase" style={{ color: '#d4af37' }}>Official</div>
                      <div className="text-[8px] font-black uppercase" style={{ color: '#d4af37' }}>Seal</div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center gap-2">
                  <div className="font-serif text-sm font-bold italic" style={{ color: '#111827' }}>
                    {format(new Date(certificate.issuedAt), 'MMMM dd, yyyy')}
                  </div>
                  <div className="h-px w-full" style={{ backgroundColor: '#e5e7eb' }} />
                  <div className="text-[10px] font-bold uppercase tracking-widest" style={{ color: '#4b5563' }}>
                    Date of Issue
                  </div>
                </div>
              </div>

              <div className="mt-4 flex w-full items-center justify-between px-12">
                <div className="flex flex-col items-center">
                  <div className="font-serif text-lg italic" style={{ color: '#1f2937' }}>QuizPro Team</div>
                  <div className="h-px w-32" style={{ backgroundColor: '#9ca3af' }} />
                  <div className="mt-1 text-[8px] font-bold uppercase tracking-widest" style={{ color: '#6b7280' }}>Authorized Signature</div>
                </div>
                <div className="text-[8px] font-medium italic" style={{ color: '#9ca3af' }}>
                  Platform Developed by Deeraj
                </div>
                <div className="flex flex-col items-center">
                  <div className="font-serif text-lg italic" style={{ color: '#1f2937' }}>Academic Director</div>
                  <div className="h-px w-32" style={{ backgroundColor: '#9ca3af' }} />
                  <div className="mt-1 text-[8px] font-bold uppercase tracking-widest" style={{ color: '#6b7280' }}>Authorized Signature</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="flex gap-4 print:hidden">
        <button
          onClick={handleDownload}
          className="flex items-center gap-2 rounded-full bg-blue-600 px-8 py-4 font-black text-white transition-transform hover:scale-105 active:scale-95"
        >
          <FileDown className="h-5 w-5" />
          DOWNLOAD PDF
        </button>
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 rounded-full border border-blue-500/20 bg-blue-500/5 px-8 py-4 font-bold text-blue-500 transition-colors hover:bg-blue-500/10"
        >
          <Printer className="h-5 w-5" />
          PRINT
        </button>
        <button
          onClick={() => navigate('/dashboard')}
          className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-8 py-4 font-bold text-white transition-colors hover:bg-white/10"
        >
          BACK TO DASHBOARD
        </button>
      </div>

      <style>{`
        @media print {
          @page {
            size: landscape;
            margin: 0;
          }
          body {
            background: white !important;
          }
          body * {
            visibility: hidden;
          }
          #certificate-content, #certificate-content * {
            visibility: visible;
          }
          #certificate-content {
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            margin: 0;
            padding: 40px;
            border: 20px solid #3b82f620 !important;
            box-shadow: none !important;
            width: 800px;
            height: 600px;
          }
        }
      `}</style>
    </div>
  );
}
