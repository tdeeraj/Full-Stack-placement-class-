import { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Link } from 'react-router-dom';
import { Clock, Award, ChevronRight, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';

interface Quiz {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  passingScore: number;
  questions: any[];
}

export default function QuizList() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'quizzes'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const quizData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Quiz));
      setQuizzes(quizData);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-12">
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl font-black tracking-tighter uppercase">Available Quizzes</h1>
        <p className="text-white/50">Select a quiz to test your knowledge and earn certificates.</p>
      </div>

      {quizzes.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-4 rounded-[2rem] border border-white/10 bg-white/5 py-24 text-center">
          <BookOpen className="h-16 w-16 text-white/20" />
          <h3 className="text-xl font-bold">No quizzes available yet.</h3>
          <p className="text-white/40">Check back later or contact an administrator.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {quizzes.map((quiz, i) => (
            <motion.div
              key={quiz.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group relative flex flex-col overflow-hidden rounded-[2rem] border border-white/10 bg-white/5 p-8 transition-all hover:border-blue-500/30 hover:bg-white/10"
            >
              <div className="mb-6 flex items-center justify-between">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-500">
                  <Award className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-white/40 uppercase tracking-widest">
                  <Clock className="h-3 w-3" />
                  {quiz.timeLimit} MINS
                </div>
              </div>

              <h3 className="mb-2 text-2xl font-black tracking-tight">{quiz.title}</h3>
              <p className="mb-8 line-clamp-2 text-sm text-white/50">{quiz.description}</p>

              <div className="mt-auto flex items-center justify-between">
                <div className="text-xs font-bold text-blue-500/80 uppercase tracking-widest">
                  Passing: {quiz.passingScore}%
                </div>
                <Link
                  to={`/quiz/${quiz.id}`}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-black transition-transform hover:scale-110 active:scale-95"
                >
                  <ChevronRight className="h-5 w-5" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
