import React, { useEffect, useState } from 'react';
import { collection, onSnapshot, query, orderBy, addDoc, deleteDoc, doc, updateDoc, where, getDocs } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { Plus, Trash2, Edit2, Users, BookOpen, Award, Check, X, Loader2, LayoutDashboard, Settings, BarChart3, Search, Filter, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

interface Quiz {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  passingScore: number;
  questions: Question[];
  createdAt: string;
}

export default function AdminDashboard() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);
  const [totalAttempts, setTotalAttempts] = useState(0);
  const [totalCertificates, setTotalCertificates] = useState(0);
  
  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [timeLimit, setTimeLimit] = useState(30);
  const [passingScore, setPassingScore] = useState(80);
  const [questions, setQuestions] = useState<Question[]>([
    { id: '1', text: '', options: ['', '', '', ''], correctAnswer: 0 }
  ]);

  useEffect(() => {
    const q = query(collection(db, 'quizzes'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const quizData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Quiz));
      setQuizzes(quizData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'quizzes');
    });

    // Fetch real-time stats
    const fetchStats = async () => {
      try {
        const attemptsSnap = await getDocs(collection(db, 'attempts'));
        const certsSnap = await getDocs(collection(db, 'certificates'));
        setTotalAttempts(attemptsSnap.size);
        setTotalCertificates(certsSnap.size);
      } catch (err) {
        console.error("Error fetching stats:", err);
      }
    };
    fetchStats();

    return () => unsubscribe();
  }, []);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setTimeLimit(30);
    setPassingScore(80);
    setQuestions([{ id: '1', text: '', options: ['', '', '', ''], correctAnswer: 0 }]);
    setEditingQuiz(null);
  };

  const handleAddQuestion = () => {
    setQuestions([...questions, { id: Date.now().toString(), text: '', options: ['', '', '', ''], correctAnswer: 0 }]);
  };

  const handleRemoveQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const handleQuestionChange = (index: number, field: keyof Question, value: any) => {
    const newQuestions = [...questions];
    newQuestions[index] = { ...newQuestions[index], [field]: value };
    setQuestions(newQuestions);
  };

  const handleOptionChange = (qIndex: number, oIndex: number, value: string) => {
    const newQuestions = [...questions];
    newQuestions[qIndex].options[oIndex] = value;
    setQuestions(newQuestions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const quizData = {
      title,
      description,
      timeLimit,
      passingScore,
      questions,
      createdBy: auth.currentUser?.uid,
      createdAt: editingQuiz ? editingQuiz.createdAt : new Date().toISOString(),
    };

    try {
      if (editingQuiz) {
        await updateDoc(doc(db, 'quizzes', editingQuiz.id), quizData);
      } else {
        await addDoc(collection(db, 'quizzes'), quizData);
      }
      setIsModalOpen(false);
      resetForm();
    } catch (err) {
      handleFirestoreError(err, editingQuiz ? OperationType.UPDATE : OperationType.CREATE, 'quizzes');
    }
  };

  const handleEdit = (quiz: Quiz) => {
    setEditingQuiz(quiz);
    setTitle(quiz.title);
    setDescription(quiz.description);
    setTimeLimit(quiz.timeLimit);
    setPassingScore(quiz.passingScore);
    setQuestions(quiz.questions);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this quiz?')) {
      try {
        await deleteDoc(doc(db, 'quizzes', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `quizzes/${id}`);
      }
    }
  };

  if (loading) return (
    <div className="flex h-[60vh] items-center justify-center">
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        className="h-12 w-12 rounded-full border-4 border-blue-500 border-t-transparent"
      />
    </div>
  );

  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      {/* Header */}
      <div className="mb-16 flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-col gap-4">
          <div className="inline-flex items-center gap-2 self-start rounded-full border border-blue-500/20 bg-blue-500/5 px-4 py-1.5 text-[10px] font-bold tracking-widest text-blue-500 uppercase">
            <LayoutDashboard className="h-3 w-3" />
            ADMINISTRATIVE CONSOLE
          </div>
          <h1 className="font-display text-5xl font-black tracking-tighter uppercase">Control <span className="text-blue-500">Center</span></h1>
        </div>
        <button
          onClick={() => { resetForm(); setIsModalOpen(true); }}
          className="group relative flex items-center gap-3 overflow-hidden rounded-full bg-blue-500 px-10 py-5 text-sm font-black text-black transition-all hover:scale-105 active:scale-95"
        >
          <Plus className="relative z-10 h-5 w-5" />
          <span className="relative z-10">CREATE NEW ASSESSMENT</span>
          <div className="absolute inset-0 -translate-x-full bg-white transition-transform group-hover:translate-x-0" />
        </button>
      </div>

      {/* Stats Bento Grid */}
      <div className="mb-16 grid gap-6 md:grid-cols-4">
        {[
          { icon: BookOpen, label: "Total Quizzes", value: quizzes.length, color: "text-blue-500", bg: "bg-blue-500/5" },
          { icon: Award, label: "Certificates Issued", value: totalCertificates, color: "text-blue-500", bg: "bg-blue-500/5" },
          { icon: Users, label: "Total Attempts", value: totalAttempts, color: "text-green-500", bg: "bg-green-500/5" },
          { icon: BarChart3, label: "Avg Pass Rate", value: totalAttempts > 0 ? `${Math.round((totalCertificates / totalAttempts) * 100)}%` : '0%', color: "text-purple-500", bg: "bg-purple-500/5" }
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass group relative overflow-hidden rounded-[2rem] p-8"
          >
            <div className={cn("mb-6 flex h-12 w-12 items-center justify-center rounded-2xl", stat.bg, stat.color)}>
              <stat.icon className="h-6 w-6" />
            </div>
            <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/30">{stat.label}</div>
            <div className="mt-1 text-4xl font-black">{stat.value}</div>
            <ArrowUpRight className="absolute top-8 right-8 h-5 w-5 text-white/10 transition-colors group-hover:text-white/40" />
          </motion.div>
        ))}
      </div>

      {/* Quiz Management Table */}
      <div className="glass overflow-hidden rounded-[2.5rem]">
        <div className="flex items-center justify-between border-b border-white/5 bg-white/5 px-10 py-8">
          <h2 className="text-xl font-black tracking-tight uppercase">Assessment Inventory</h2>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute top-1/2 left-4 h-4 w-4 -translate-y-1/2 text-white/20" />
              <input 
                placeholder="Search assessments..." 
                className="rounded-full border border-white/10 bg-white/5 py-2 pr-6 pl-12 text-xs outline-none focus:border-blue-500/50"
              />
            </div>
            <button className="rounded-full border border-white/10 bg-white/5 p-2 text-white/40 hover:text-white">
              <Filter className="h-4 w-4" />
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-white/5 text-[10px] font-bold uppercase tracking-[0.2em] text-white/20">
                <th className="px-10 py-6">Title</th>
                <th className="px-10 py-6">Structure</th>
                <th className="px-10 py-6">Parameters</th>
                <th className="px-10 py-6">Created At</th>
                <th className="px-10 py-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {quizzes.map((quiz) => (
                <tr key={quiz.id} className="group transition-colors hover:bg-white/5">
                  <td className="px-10 py-8">
                    <div className="font-display text-lg font-black tracking-tight uppercase">{quiz.title}</div>
                    <div className="mt-1 line-clamp-1 text-xs text-white/30">{quiz.description}</div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 text-[10px] font-bold text-white/40 uppercase tracking-widest">
                      {quiz.questions.length} QUESTIONS
                    </div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex flex-col gap-1">
                      <div className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Limit: {quiz.timeLimit}m</div>
                      <div className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Pass: {quiz.passingScore}%</div>
                    </div>
                  </td>
                  <td className="px-10 py-8 text-xs font-medium text-white/30">
                    {new Date(quiz.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-10 py-8 text-right">
                    <div className="flex justify-end gap-3">
                      <button 
                        onClick={() => handleEdit(quiz)} 
                        className="rounded-xl border border-white/10 bg-white/5 p-3 text-white/40 transition-all hover:border-blue-500/50 hover:bg-blue-500/10 hover:text-blue-500"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button 
                        onClick={() => handleDelete(quiz.id)} 
                        className="rounded-xl border border-white/10 bg-white/5 p-3 text-white/40 transition-all hover:border-red-500/50 hover:bg-red-500/10 hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Editor Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative h-full max-h-[90vh] w-full max-w-5xl overflow-hidden rounded-[3rem] border border-white/10 bg-[#080808] shadow-2xl"
            >
              <div className="flex h-full flex-col">
                <div className="flex items-center justify-between border-b border-white/5 px-12 py-8">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-500 text-black">
                      <Settings className="h-5 w-5" />
                    </div>
                    <h2 className="text-2xl font-black tracking-tighter uppercase">
                      {editingQuiz ? 'Edit Assessment' : 'New Assessment'}
                    </h2>
                  </div>
                  <button onClick={() => setIsModalOpen(false)} className="rounded-full bg-white/5 p-2 transition-colors hover:bg-white/10">
                    <X className="h-6 w-6" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-12">
                  <div className="grid gap-12 lg:grid-cols-3">
                    {/* Sidebar: Config */}
                    <div className="flex flex-col gap-8 lg:col-span-1">
                      <div className="flex flex-col gap-6 rounded-3xl border border-white/5 bg-white/5 p-8">
                        <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-blue-500">Parameters</h3>
                        <div className="flex flex-col gap-4">
                          <div className="flex flex-col gap-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-white/30">Title</label>
                            <input
                              required
                              value={title}
                              onChange={(e) => setTitle(e.target.value)}
                              className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-blue-500/50"
                              placeholder="Assessment Name"
                            />
                          </div>
                          <div className="flex flex-col gap-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-white/30">Time Limit (Min)</label>
                            <input
                              required
                              type="number"
                              value={timeLimit}
                              onChange={(e) => setTimeLimit(parseInt(e.target.value))}
                              className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-blue-500/50"
                            />
                          </div>
                          <div className="flex flex-col gap-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-white/30">Passing Score (%)</label>
                            <input
                              required
                              type="number"
                              value={passingScore}
                              onChange={(e) => setPassingScore(parseInt(e.target.value))}
                              className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-blue-500/50"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-white/30">Description</label>
                        <textarea
                          required
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          className="h-32 rounded-2xl border border-white/10 bg-white/5 px-6 py-4 text-sm outline-none focus:border-blue-500/50"
                          placeholder="What skills are being tested?"
                        />
                      </div>
                    </div>

                    {/* Main: Questions */}
                    <div className="flex flex-col gap-8 lg:col-span-2">
                      <div className="flex items-center justify-between">
                        <h3 className="text-xl font-black tracking-tight uppercase">Questions ({questions.length})</h3>
                        <button
                          type="button"
                          onClick={handleAddQuestion}
                          className="flex items-center gap-2 rounded-full bg-white/5 px-4 py-2 text-xs font-bold text-blue-500 transition-colors hover:bg-blue-500/10"
                        >
                          <Plus className="h-4 w-4" />
                          ADD ITEM
                        </button>
                      </div>

                      <div className="flex flex-col gap-6">
                        {questions.map((q, qIndex) => (
                          <motion.div 
                            key={q.id} 
                            initial={{ opacity: 0, x: 20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="relative rounded-[2rem] border border-white/5 bg-white/5 p-10"
                          >
                            <button
                              type="button"
                              onClick={() => handleRemoveQuestion(qIndex)}
                              className="absolute top-10 right-10 text-white/10 hover:text-red-500"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                            
                            <div className="mb-8 flex flex-col gap-2">
                              <label className="text-[10px] font-bold uppercase tracking-widest text-white/20">Item {qIndex + 1}</label>
                              <input
                                required
                                value={q.text}
                                onChange={(e) => handleQuestionChange(qIndex, 'text', e.target.value)}
                                className="border-b border-white/10 bg-transparent py-2 text-xl font-bold outline-none focus:border-blue-500"
                                placeholder="Enter question text..."
                              />
                            </div>

                            <div className="grid gap-4 md:grid-cols-2">
                              {q.options.map((opt, oIndex) => (
                                <div key={oIndex} className="flex items-center gap-4">
                                  <button
                                    type="button"
                                    onClick={() => handleQuestionChange(qIndex, 'correctAnswer', oIndex)}
                                    className={cn(
                                      "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border-2 transition-all",
                                      q.correctAnswer === oIndex 
                                        ? "border-blue-500 bg-blue-500 text-black" 
                                        : "border-white/10 bg-white/5 text-white/20 hover:border-white/30"
                                    )}
                                  >
                                    {q.correctAnswer === oIndex ? <Check className="h-5 w-5" /> : String.fromCharCode(65 + oIndex)}
                                  </button>
                                  <input
                                    required
                                    value={opt}
                                    onChange={(e) => handleOptionChange(qIndex, oIndex, e.target.value)}
                                    className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none focus:border-blue-500/50"
                                    placeholder={`Option ${String.fromCharCode(65 + oIndex)}`}
                                  />
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </form>

                <div className="border-t border-white/5 bg-white/5 px-12 py-8">
                  <button
                    type="submit"
                    onClick={(e) => handleSubmit(e as any)}
                    className="group relative flex w-full items-center justify-center gap-3 overflow-hidden rounded-full bg-blue-500 py-6 text-xl font-black text-black transition-all hover:scale-[1.01] active:scale-[0.99]"
                  >
                    <span className="relative z-10 uppercase">{editingQuiz ? 'Commit Changes' : 'Deploy Assessment'}</span>
                    <div className="absolute inset-0 -translate-x-full bg-white transition-transform group-hover:translate-x-0" />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
