import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { Award, Chrome, Loader2, User, ShieldCheck, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [loginType, setLoginType] = useState<'student' | 'admin' | null>(null);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      navigate(loginType === 'admin' ? '/admin' : '/dashboard');
    } catch (err: any) {
      console.error(err);
      setError('Failed to sign in with Google. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-[80vh] items-center justify-center overflow-hidden px-6">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -z-10 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-blue-500/10 blur-[120px]" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-4xl"
      >
        <AnimatePresence mode="wait">
          {!loginType ? (
            <motion.div
              key="choice"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid gap-8 md:grid-cols-2"
            >
              {[
                {
                  id: 'student',
                  title: 'Student Portal',
                  desc: 'Take assessments, track progress, and earn certificates.',
                  icon: User,
                  color: 'text-blue-500',
                  bg: 'bg-blue-500/10'
                },
                {
                  id: 'admin',
                  title: 'Admin Console',
                  desc: 'Manage quizzes, monitor students, and issue certifications.',
                  icon: ShieldCheck,
                  color: 'text-cyan-500',
                  bg: 'bg-cyan-500/10'
                }
              ].map((type) => (
                <button
                  key={type.id}
                  onClick={() => setLoginType(type.id as any)}
                  className="group relative flex flex-col items-start gap-6 rounded-[2.5rem] border border-white/10 bg-white/5 p-12 text-left transition-all hover:border-white/20 hover:bg-white/10"
                >
                  <div className={cn("flex h-16 w-16 items-center justify-center rounded-2xl", type.bg, type.color)}>
                    <type.icon className="h-8 w-8" />
                  </div>
                  <div>
                    <h3 className="text-3xl font-black tracking-tighter uppercase">{type.title}</h3>
                    <p className="mt-2 text-white/50">{type.desc}</p>
                  </div>
                  <div className="mt-8 flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-white/30 transition-colors group-hover:text-white">
                    Continue to Login
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </button>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="login"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mx-auto max-w-md overflow-hidden rounded-[3rem] border border-white/10 bg-white/5 p-12 text-center backdrop-blur-xl"
            >
              <button
                onClick={() => setLoginType(null)}
                className="mb-8 text-xs font-bold uppercase tracking-widest text-white/30 hover:text-white"
              >
                ← Back to Choice
              </button>

              <div className="mb-12 flex flex-col items-center gap-6">
                <div className={cn(
                  "flex h-20 w-20 items-center justify-center rounded-[2rem] text-black",
                  loginType === 'admin' ? "bg-cyan-500" : "bg-blue-500"
                )}>
                  {loginType === 'admin' ? <ShieldCheck className="h-10 w-10" /> : <User className="h-10 w-10" />}
                </div>
                <div>
                  <h2 className="text-4xl font-black tracking-tighter uppercase">
                    {loginType === 'admin' ? 'Admin Login' : 'Student Login'}
                  </h2>
                  <p className="mt-2 text-white/50">Securely sign in with your Google account</p>
                </div>
              </div>

              {error && (
                <div className="mb-8 rounded-2xl bg-red-500/10 p-4 text-sm text-red-400 border border-red-500/20">
                  {error}
                </div>
              )}

              <button
                onClick={handleGoogleLogin}
                disabled={loading}
                className="group relative flex w-full items-center justify-center gap-4 rounded-full bg-white px-8 py-5 text-lg font-black text-black transition-transform hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  <>
                    <Chrome className="h-6 w-6" />
                    CONTINUE WITH GOOGLE
                  </>
                )}
              </button>

              <p className="mt-12 text-[10px] font-bold uppercase tracking-[0.2em] text-white/20">
                Enterprise Grade Security • Powered by Firebase
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
