import React, { useEffect, useState } from 'react';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../lib/AuthContext';
import { Link } from 'react-router-dom';
import { BookOpen, Award, Clock, ChevronRight, FileText, CheckCircle2, XCircle, Sparkles, TrendingUp, Target } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';

interface Quiz {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  passingScore: number;
}

interface Attempt {
  id: string;
  quizId: string;
  score: number;
  passed: boolean;
  completedAt: string;
}

interface Certificate {
  id: string;
  quizId: string;
  quizTitle: string;
  attemptId: string;
  issuedAt: string;
}

export default function UserDashboard() {
  const { profile } = useAuth();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'quizzes' | 'history' | 'certificates'>('quizzes');

  useEffect(() => {
    if (!profile) return;

    const quizzesQuery = query(collection(db, 'quizzes'), orderBy('createdAt', 'desc'));
    const attemptsQuery = query(collection(db, 'attempts'), where('userId', '==', profile.uid), orderBy('completedAt', 'desc'));
    const certificatesQuery = query(collection(db, 'certificates'), where('userId', '==', profile.uid), orderBy('issuedAt', 'desc'));

    const unsubQuizzes = onSnapshot(quizzesQuery, (snap) => {
      setQuizzes(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Quiz)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'quizzes');
    });

    const unsubAttempts = onSnapshot(attemptsQuery, (snap) => {
      setAttempts(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Attempt)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'attempts');
    });

    const unsubCertificates = onSnapshot(certificatesQuery, (snap) => {
      setCertificates(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Certificate)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'certificates');
    });

    return () => {
      unsubQuizzes();
      unsubAttempts();
      unsubCertificates();
    };
  }, [profile]);

  if (loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="h-12 w-12 rounded-full border-4 border-blue-500 border-t-transparent"
        />
      </div>
    );
  }

  const stats = [
    { label: 'Completed', value: attempts.length, icon: CheckCircle2, color: 'text-green-500' },
    { label: 'Certificates', value: certificates.length, icon: Award, color: 'text-blue-500' },
    { label: 'Avg Score', value: attempts.length > 0 ? `${Math.round(attempts.reduce((acc, curr) => acc + curr.score, 0) / attempts.length)}%` : '0%', icon: TrendingUp, color: 'text-cyan-500' },
  ];

  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      {/* Header Section */}
      <div className="mb-16 flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
        <div className="flex flex-col gap-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="inline-flex items-center gap-2 self-start rounded-full border border-blue-500/20 bg-blue-500/5 px-4 py-1.5 text-xs font-bold tracking-widest text-blue-500 uppercase"
          >
            <Sparkles className="h-3 w-3" />
            STUDENT PORTAL
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-display text-6xl font-black tracking-tighter uppercase"
          >
            Welcome, <span className="text-blue-500">{profile?.displayName?.split(' ')[0]}</span>
          </motion.h1>
        </div>

        {/* Quick Stats Bento */}
        <div className="flex flex-wrap gap-4">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
              className="glass flex items-center gap-4 rounded-3xl px-8 py-4"
            >
              <stat.icon className={cn("h-6 w-6", stat.color)} />
              <div>
                <div className="text-2xl font-black tracking-tighter">{stat.value}</div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30">{stat.label}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="mb-12 flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {[
          { id: 'quizzes', label: 'Available Assessments', icon: BookOpen },
          { id: 'history', label: 'Attempt History', icon: Clock },
          { id: 'certificates', label: 'My Certifications', icon: Award },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "relative flex shrink-0 items-center gap-3 rounded-full px-8 py-4 text-sm font-black uppercase tracking-widest transition-all",
              activeTab === tab.id 
                ? "bg-white text-black" 
                : "text-white/40 hover:bg-white/5 hover:text-white"
            )}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 -z-10 rounded-full bg-white"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              />
            )}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4 }}
          className="min-h-[400px]"
        >
          {activeTab === 'quizzes' && (
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {quizzes.map((quiz, i) => (
                <motion.div
                  key={quiz.id}
                  whileHover={{ y: -10, scale: 1.02 }}
                  className="group relative flex flex-col overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/5 p-10 transition-all hover:border-blue-500/40 hover:bg-white/10"
                >
                  <div className="mb-8 flex items-center justify-between">
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-500">
                      <BookOpen className="h-7 w-7" />
                    </div>
                    <div className="flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 text-[10px] font-bold text-white/40 uppercase tracking-widest">
                      <Clock className="h-3 w-3" />
                      {quiz.timeLimit} MINS
                    </div>
                  </div>
                  <h3 className="mb-4 font-display text-3xl font-black leading-tight tracking-tight uppercase">{quiz.title}</h3>
                  <p className="mb-8 line-clamp-2 text-sm leading-relaxed text-white/40">{quiz.description}</p>
                  
                  <div className="mt-auto flex items-center justify-between border-t border-white/5 pt-8">
                    <div className="flex flex-col">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/20">Passing Score</span>
                      <span className="text-lg font-black text-blue-500">{quiz.passingScore}%</span>
                    </div>
                    <Link
                      to={`/quiz/${quiz.id}`}
                      className="group/btn relative flex h-14 w-14 items-center justify-center overflow-hidden rounded-full bg-white text-black transition-transform hover:scale-110 active:scale-95"
                    >
                      <ChevronRight className="relative z-10 h-6 w-6 transition-transform group-hover/btn:translate-x-1" />
                      <div className="absolute inset-0 -translate-x-full bg-blue-500 transition-transform group-hover/btn:translate-x-0" />
                    </Link>
                  </div>
                </motion.div>
              ))}
              {quizzes.length === 0 && (
                <div className="col-span-full flex flex-col items-center justify-center py-32 text-center">
                  <BookOpen className="mb-4 h-12 w-12 text-white/10" />
                  <div className="text-xl font-bold text-white/20 uppercase tracking-widest">No assessments available</div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/5 backdrop-blur-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-white/10 bg-white/5 text-[10px] font-bold uppercase tracking-[0.2em] text-white/30">
                      <th className="px-10 py-8">Assessment</th>
                      <th className="px-10 py-8">Performance</th>
                      <th className="px-10 py-8">Status</th>
                      <th className="px-10 py-8">Completion Date</th>
                      <th className="px-10 py-8 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {attempts.map((attempt) => {
                      const quiz = quizzes.find(q => q.id === attempt.quizId);
                      return (
                        <tr key={attempt.id} className="group transition-colors hover:bg-white/5">
                          <td className="px-10 py-8">
                            <div className="font-display text-xl font-black tracking-tight uppercase">{quiz?.title || 'Archived Quiz'}</div>
                          </td>
                          <td className="px-10 py-8">
                            <div className="flex items-center gap-4">
                              <div className="h-2 w-24 rounded-full bg-white/10">
                                <div 
                                  className={cn("h-full rounded-full", attempt.passed ? "bg-green-500" : "bg-red-500")}
                                  style={{ width: `${attempt.score}%` }}
                                />
                              </div>
                              <span className={cn("text-lg font-black", attempt.passed ? "text-green-500" : "text-red-500")}>
                                {attempt.score}%
                              </span>
                            </div>
                          </td>
                          <td className="px-10 py-8">
                            <div className={cn(
                              "inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-[10px] font-bold uppercase tracking-widest",
                              attempt.passed ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                            )}>
                              {attempt.passed ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                              {attempt.passed ? 'PASSED' : 'FAILED'}
                            </div>
                          </td>
                          <td className="px-10 py-8 text-sm font-medium text-white/40">
                            {format(new Date(attempt.completedAt), 'MMM dd, yyyy • HH:mm')}
                          </td>
                          <td className="px-10 py-8 text-right">
                            {attempt.passed && (
                              <Link
                                to={`/certificate/${attempt.id}`}
                                className="inline-flex items-center gap-2 rounded-full border border-blue-500/20 bg-blue-500/5 px-6 py-2.5 text-[10px] font-bold text-blue-500 transition-all hover:bg-blue-500 hover:text-black"
                              >
                                <Award className="h-3 w-3" />
                                CERTIFICATE
                              </Link>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                    {attempts.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-32 text-center">
                          <Clock className="mx-auto mb-4 h-12 w-12 text-white/10" />
                          <div className="text-xl font-bold text-white/20 uppercase tracking-widest">No attempt history found</div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'certificates' && (
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {certificates.map((cert, i) => (
                <motion.div
                  key={cert.id}
                  whileHover={{ 
                    scale: 1.05,
                    rotateY: 10,
                    rotateX: -5,
                    transition: { type: "spring", stiffness: 300, damping: 20 }
                  }}
                  className="perspective-1000 preserve-3d group relative flex flex-col rounded-[2.5rem] border border-white/10 bg-white/5 p-10 transition-all hover:border-blue-500/40 hover:bg-white/10"
                >
                  <div className="absolute top-0 right-0 -z-10 h-32 w-32 rounded-full bg-blue-500/5 blur-3xl transition-all group-hover:bg-blue-500/20" />
                  <div className="relative z-10">
                    <Award className="mb-8 h-16 w-16 text-blue-500 transition-transform group-hover:scale-110" />
                    <h3 className="mb-4 font-display text-2xl font-black leading-tight tracking-tight uppercase">{cert.quizTitle}</h3>
                    <div className="mb-10 flex flex-col gap-1">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-white/20">Issued On</span>
                      <span className="text-sm font-bold text-white/60">{format(new Date(cert.issuedAt), 'MMMM dd, yyyy')}</span>
                    </div>
                    <Link
                      to={`/certificate/${cert.attemptId}`}
                      className="mt-auto flex items-center justify-center gap-3 rounded-full bg-white py-5 text-sm font-black text-black transition-all hover:bg-blue-500 hover:scale-[1.02]"
                    >
                      <FileText className="h-5 w-5" />
                      VIEW CREDENTIAL
                    </Link>
                  </div>
                </motion.div>
              ))}
              {certificates.length === 0 && (
                <div className="col-span-full flex flex-col items-center justify-center py-32 text-center">
                  <Award className="mb-4 h-12 w-12 text-white/10" />
                  <div className="text-xl font-bold text-white/20 uppercase tracking-widest">No certifications earned yet</div>
                  <p className="mt-2 text-sm text-white/40">Pass an assessment with 80% or higher to unlock your certificate.</p>
                </div>
              )}
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
