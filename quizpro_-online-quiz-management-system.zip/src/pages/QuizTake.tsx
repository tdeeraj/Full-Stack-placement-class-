import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, addDoc, collection } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../lib/AuthContext';
import { Clock, ChevronRight, ChevronLeft, Award, Loader2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { cn } from '../lib/utils';

interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

interface Quiz {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  passingScore: number;
  questions: Question[];
}

export default function QuizTake() {
  const { id } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [result, setResult] = useState<{ score: number; passed: boolean; attemptId: string } | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const fetchQuiz = async () => {
      if (!id) return;
      const docRef = doc(db, 'quizzes', id);
      try {
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data() as Quiz;
          setQuiz({ ...data, id: docSnap.id });
          setTimeLeft(data.timeLimit * 60);
          setAnswers(new Array(data.questions.length).fill(-1));
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `quizzes/${id}`);
      }
      setLoading(false);
    };
    fetchQuiz();
  }, [id]);

  useEffect(() => {
    if (!isFinished && timeLeft > 0) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            handleSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isFinished, timeLeft]);

  const handleOptionSelect = (optionIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);
  };

  const handleSubmit = async () => {
    if (!quiz || !profile || isFinished) return;
    setIsFinished(true);
    if (timerRef.current) clearInterval(timerRef.current);

    let correctCount = 0;
    quiz.questions.forEach((q, i) => {
      if (answers[i] === q.correctAnswer) correctCount++;
    });

    const score = Math.round((correctCount / quiz.questions.length) * 100);
    const passed = score >= quiz.passingScore;

    const attemptData = {
      userId: profile.uid,
      quizId: quiz.id,
      score,
      passed,
      answers,
      completedAt: new Date().toISOString(),
    };

    try {
      const attemptRef = await addDoc(collection(db, 'attempts'), attemptData);
      
      if (passed) {
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#f97316', '#ffffff', '#000000']
        });

        // Create certificate
        try {
          await addDoc(collection(db, 'certificates'), {
            userId: profile.uid,
            quizId: quiz.id,
            attemptId: attemptRef.id,
            userName: profile.displayName,
            quizTitle: quiz.title,
            issuedAt: new Date().toISOString(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, 'certificates');
        }
      }

      setResult({ score, passed, attemptId: attemptRef.id });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'attempts');
    }
  };

  if (loading) return (
    <div className="flex h-[60vh] items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
    </div>
  );

  if (!quiz) return (
    <div className="flex flex-col items-center justify-center gap-4 py-24 text-center">
      <AlertCircle className="h-16 w-16 text-red-500/50" />
      <h2 className="text-2xl font-bold">Quiz not found</h2>
      <button onClick={() => navigate('/quizzes')} className="text-blue-500 underline">Back to Quizzes</button>
    </div>
  );

  if (result) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="mx-auto max-w-2xl overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/5 p-12 text-center backdrop-blur-xl"
      >
        <div className="mb-8 flex flex-col items-center gap-4">
          <div className={cn(
            "flex h-20 w-20 items-center justify-center rounded-3xl text-black",
            result.passed ? "bg-green-500" : "bg-red-500"
          )}>
            <Award className="h-12 w-12" />
          </div>
          <div>
            <h2 className="text-4xl font-black tracking-tighter uppercase">
              {result.passed ? "CONGRATULATIONS!" : "QUIZ COMPLETED"}
            </h2>
            <p className="text-white/50">You've finished the {quiz.title} assessment.</p>
          </div>
        </div>

        <div className="mb-12 grid grid-cols-2 gap-4">
          <div className="rounded-2xl bg-white/5 p-6">
            <div className="text-xs font-bold text-white/30 uppercase tracking-widest">Your Score</div>
            <div className={cn("text-4xl font-black", result.passed ? "text-green-500" : "text-red-500")}>
              {result.score}%
            </div>
          </div>
          <div className="rounded-2xl bg-white/5 p-6">
            <div className="text-xs font-bold text-white/30 uppercase tracking-widest">Status</div>
            <div className={cn("text-4xl font-black", result.passed ? "text-green-500" : "text-red-500")}>
              {result.passed ? "PASSED" : "FAILED"}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          {result.passed && (
            <button
              onClick={() => navigate(`/certificate/${result.attemptId}`)}
              className="rounded-full bg-blue-500 py-4 text-lg font-black text-black transition-transform hover:scale-105 active:scale-95"
            >
              VIEW CERTIFICATE
            </button>
          )}
          <button
            onClick={() => navigate('/quizzes')}
            className="rounded-full border border-white/10 bg-white/5 py-4 text-lg font-black text-white transition-colors hover:bg-white/10"
          >
            BACK TO DASHBOARD
          </button>
        </div>
      </motion.div>
    );
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100;

  return (
    <div className="mx-auto max-w-4xl">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-black tracking-tight uppercase">{quiz.title}</h1>
          <div className="flex items-center gap-4 text-xs font-bold text-white/40 uppercase tracking-widest">
            <span>Question {currentQuestion + 1} of {quiz.questions.length}</span>
          </div>
        </div>
        <div className={cn(
          "flex items-center gap-3 rounded-2xl border px-6 py-3 font-mono text-xl font-bold",
          timeLeft < 60 ? "border-red-500/50 bg-red-500/10 text-red-500" : "border-white/10 bg-white/5 text-blue-500"
        )}>
          <Clock className="h-5 w-5" />
          {formatTime(timeLeft)}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-12 h-1 w-full overflow-hidden rounded-full bg-white/5">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          className="h-full bg-blue-500"
        />
      </div>

      {/* Question Card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="rounded-[2.5rem] border border-white/10 bg-white/5 p-12 backdrop-blur-xl"
        >
          <h2 className="mb-12 text-3xl font-bold leading-tight">
            {quiz.questions[currentQuestion].text}
          </h2>

          <div className="grid gap-4">
            {quiz.questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionSelect(index)}
                className={cn(
                  "group flex items-center justify-between rounded-2xl border p-6 text-left transition-all",
                  answers[currentQuestion] === index
                    ? "border-blue-500 bg-blue-500/10 text-blue-500"
                    : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10"
                )}
              >
                <span className="text-lg font-medium">{option}</span>
                <div className={cn(
                  "h-6 w-6 rounded-full border-2 flex items-center justify-center transition-colors",
                  answers[currentQuestion] === index
                    ? "border-blue-500 bg-blue-500"
                    : "border-white/20 group-hover:border-white/40"
                )}>
                  {answers[currentQuestion] === index && <div className="h-2 w-2 rounded-full bg-black" />}
                </div>
              </button>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="mt-8 flex items-center justify-between">
        <button
          onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
          disabled={currentQuestion === 0}
          className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-8 py-4 font-bold text-white transition-colors hover:bg-white/10 disabled:opacity-30"
        >
          <ChevronLeft className="h-5 w-5" />
          PREVIOUS
        </button>

        {currentQuestion === quiz.questions.length - 1 ? (
          <button
            onClick={handleSubmit}
            className="flex items-center gap-2 rounded-full bg-blue-500 px-12 py-4 font-black text-black transition-transform hover:scale-105 active:scale-95"
          >
            FINISH ASSESSMENT
          </button>
        ) : (
          <button
            onClick={() => setCurrentQuestion(prev => Math.min(quiz.questions.length - 1, prev + 1))}
            className="flex items-center gap-2 rounded-full bg-white px-8 py-4 font-bold text-black transition-transform hover:scale-105 active:scale-95"
          >
            NEXT
            <ChevronRight className="h-5 w-5" />
          </button>
        )}
      </div>
    </div>
  );
}
